module.exports = { value: 7, label: "q26-bad" };
