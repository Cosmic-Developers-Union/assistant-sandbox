module.exports = { value: 42, label: "q26-pure" };
