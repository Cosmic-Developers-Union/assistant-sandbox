module.exports = require("./q23_addon.node");
