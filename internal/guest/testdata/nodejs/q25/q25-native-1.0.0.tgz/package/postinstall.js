const fs = require("node:fs");
fs.writeFileSync("installed.txt", "q25-native-postinstall\n");
