module.exports = { value: 21, label: "q25-pure" };
