import base64
import hashlib
import os
import shutil
import subprocess
subprocess._USE_VFORK = False
import sysconfig
import zipfile

NAME = "q29_native"
VERSION = "1.0"
DIST_INFO = f"{NAME}-{VERSION}.dist-info"



def _hash(data):
    digest = hashlib.sha256(data).digest()
    return "sha256=" + base64.urlsafe_b64encode(digest).rstrip(b"=").decode()


def prepare_metadata_for_build_wheel(metadata_directory, config_settings=None):
    root = os.path.join(metadata_directory, DIST_INFO)
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, "METADATA"), "wb") as metadata:
        metadata.write((f"Metadata-Version: 2.1\nName: {NAME}\nVersion: {VERSION}\n").encode())
    with open(os.path.join(root, "WHEEL"), "wb") as wheel:
        wheel.write((
            "Wheel-Version: 1.0\n"
            "Generator: q29-backend\n"
            "Root-Is-Purelib: false\n"
            "Tag: cp312-cp312-linux_riscv64\n"
        ).encode())
    return DIST_INFO


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    suffix = sysconfig.get_config_var("EXT_SUFFIX")
    if not suffix:
        raise RuntimeError("missing EXT_SUFFIX")
    module = NAME + suffix
    subprocess.run(
        ["/usr/bin/tcc", "-shared", "-fPIC", "-O2",
         "-I/usr/include/python3.12", "-o", module, "q29_native.c"],
        check=True,
    )
    metadata = (f"Metadata-Version: 2.1\nName: {NAME}\nVersion: {VERSION}\n").encode()
    wheel = (
        "Wheel-Version: 1.0\n"
        "Generator: q29-backend\n"
        "Root-Is-Purelib: false\n"
        "Tag: cp312-cp312-linux_riscv64\n"
    ).encode()
    entries = {
        module: open(module, "rb").read(),
        f"{DIST_INFO}/METADATA": metadata,
        f"{DIST_INFO}/WHEEL": wheel,
    }
    records = []
    for name, content in entries.items():
        records.append(f"{name},{_hash(content)},{len(content)}\n")
    records.append(f"{DIST_INFO}/RECORD,,\n")
    wheel_name = f"{NAME}-{VERSION}-cp312-cp312-linux_riscv64.whl"
    os.makedirs(wheel_directory, exist_ok=True)
    with zipfile.ZipFile(os.path.join(wheel_directory, wheel_name), "w", zipfile.ZIP_DEFLATED) as archive:
        for name, content in entries.items():
            archive.writestr(name, content)
        archive.writestr(f"{DIST_INFO}/RECORD", "".join(records).encode())
    built = os.path.join(wheel_directory, wheel_name)
    if os.path.isdir("/work"):
        shutil.copyfile(built, "/work/q29-built.whl")
    return wheel_name
