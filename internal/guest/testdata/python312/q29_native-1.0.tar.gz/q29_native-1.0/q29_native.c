#define PY_SSIZE_T_CLEAN
#include <Python.h>

static PyObject *q29_add(PyObject *self, PyObject *args) {
    long left, right;
    if (!PyArg_ParseTuple(args, "ll", &left, &right)) return NULL;
    return PyLong_FromLong(left + right);
}

static PyMethodDef q29_methods[] = {
    {"add", q29_add, METH_VARARGS, "Add two integers in native code."},
    {NULL, NULL, 0, NULL},
};

static struct PyModuleDef q29_module = {
    PyModuleDef_HEAD_INIT,
    "q29_native",
    "Q29 guest-built extension.",
    -1,
    q29_methods,
};

PyMODINIT_FUNC PyInit_q29_native(void) {
    return PyModule_Create(&q29_module);
}
