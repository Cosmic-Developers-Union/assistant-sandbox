VALUE = 42

def answer():
    return VALUE
