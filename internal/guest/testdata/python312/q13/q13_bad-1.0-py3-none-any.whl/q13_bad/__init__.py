VALUE = 7

def answer():
    return VALUE
